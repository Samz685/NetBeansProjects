
package com.mycompany.ejercicio03;


public class VariableCompartida  {
    
  int v ;
  
    
    public VariableCompartida () {
        this.v=0;
    }
    
    public void  setValor(int valor){
        
        this.v = valor;
    }
    
    public int getValor() {
        
    return v;
    }
     
   public void inc() {
       
        v++;
    }
            
            
 
}

