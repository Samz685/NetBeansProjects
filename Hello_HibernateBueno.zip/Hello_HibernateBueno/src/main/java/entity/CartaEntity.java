package entity;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
@Table(name = "carta", schema = "comanda_desayunos", catalog = "")
public class CartaEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id")
    private int id;
    @Basic
    @Column(name = "nombre")
    private String nombre;
    @Basic
    @Column(name = "tipo")
    private String tipo;
    @Basic
    @Column(name = "precio")
    private double precio;
    @Basic
    @Column(name = "cantidad")
    private int cantidad;
    @Basic
    @Column(name = "disponibilidad")
    private byte disponibilidad;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public byte getDisponibilidad() {
        return disponibilidad;
    }

    public void setDisponibilidad(byte disponibilidad) {
        this.disponibilidad = disponibilidad;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CartaEntity that = (CartaEntity) o;
        return id == that.id && Double.compare(that.precio, precio) == 0 && cantidad == that.cantidad && disponibilidad == that.disponibilidad && Objects.equals(nombre, that.nombre) && Objects.equals(tipo, that.tipo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, nombre, tipo, precio, cantidad, disponibilidad);
    }

    @Override
    public String toString() {
        return nombre + " " + tipo + " " + precio + " ||";
    }
}
