package dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import entity.CartaEntity;
import org.hibernate.query.Query;
import utils.HibernateUtils;

import java.util.ArrayList;
import java.util.List;

public class CartaDAO {

    public static List<CartaEntity> getAllStudent() {
        Session session = HibernateUtils.getSessionFactory().openSession();
        List carta = null;
        try {
            final String query_sql = "SELECT carta FROM CartaEntity carta";
            Query query = session.createQuery(query_sql);
            carta = query.list();


        } catch (HibernateException e) {
            System.err.println(e);
        }finally {
            session.close();
        }
        return carta;
    }


}
