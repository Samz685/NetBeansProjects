import dao.CartaDAO;
import entity.CartaEntity;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<CartaEntity> carta = new ArrayList<>();
        carta = CartaDAO.getAllStudent();

        carta.forEach(k -> {
            System.out.println(k);
        });
    }
}
